#ifndef CIRCLE_H
#define CIRCLE_H
#include<iostream>
#include"Shape.h"

class Circle :public Shape {
private:
protected:
public:
	Circle();
	~Circle();
	void doDraw ();
};

#endif


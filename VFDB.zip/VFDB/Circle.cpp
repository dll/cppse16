#include "Circle.h"
using namespace std;
Circle::Circle() {
	
}

Circle::~Circle() {
	
}

void Circle::doDraw () {        	// ��ͼ	cout <<"��Բ"<<endl;}

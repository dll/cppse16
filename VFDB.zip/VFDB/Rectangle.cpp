#include "Rectangle.h"

using namespace std;

Rectangle::Rectangle() {
	
}

Rectangle::~Rectangle() {
	
}

void Rectangle::doDraw () {        	// ��ͼ
	cout <<"������"<<endl;
}

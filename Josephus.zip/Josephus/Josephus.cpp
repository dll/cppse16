#include "Josephus.h"
#include <iostream>
#include<iomanip>
using namespace std;list<int> JosephusProblem::josephusList;	// ��̬��Ա���ⲿ��ʼ��
queue<int> JosephusProblem::josephusQueue;JosephusProblem::JosephusProblem(int ls,int st,int fr){	// ���캯��
	}void JosephusProblem::display(){}void JosephusProblem::deleteElement() { 	} void JosephusProblem::saveJosephusSeq(){
	
}

void makeTestPapers(vector<JosephusProblem*> testPapers, int tps, int ls){
	
}
void JosephusProblem::makeJosephusSeq() { 
	 
} 
void JosephusProblem::JosephusQueue(){
	
}

#include "LevelControlPoint.h"
LevelControlPoint::LevelControlPoint(void)
{
	strName="";
	strID="";
	H=0;
	flag=0;
}
LevelControlPoint::~LevelControlPoint(void)
{
}

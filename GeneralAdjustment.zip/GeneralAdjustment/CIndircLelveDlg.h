#ifndef CINDIRCLELVEDLG_H
#define CINDIRCLELVEDLG_H

class CIndircLelveDlg {
private:
protected:
public:
	CIndircLelveDlg();
	~CIndircLelveDlg();
	void OnBnClickedOpendatafile();
};

#endif


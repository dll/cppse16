#include "CIndircLelveDlg.h"

CIndircLelveDlg::CIndircLelveDlg() {
	
}

CIndircLelveDlg::~CIndircLelveDlg() {
	
}


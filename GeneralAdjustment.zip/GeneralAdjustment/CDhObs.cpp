#include "CDhObs.h"

CDhObs::CDhObs() {
	
}

CDhObs::~CDhObs() {
	
}


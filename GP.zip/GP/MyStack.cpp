#include "MyStack.hpp"

//StackTmp::StackTmp() {
//	
//}
//
//StackTmp::~StackTmp() {
//	
//}
//
